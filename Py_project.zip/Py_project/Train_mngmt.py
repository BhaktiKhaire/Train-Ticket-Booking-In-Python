import os

class trainMgmt:
#For User Login
    def display(self):
        if(os.path.exists("data.txt")):  #file exists or not
            with open("data.txt", 'r') as fp:  #File open & close
                for e in fp:  #line by line read data
                    print(e)
        else:
            print("File does not exist")

    def view(self,e):
        f=open("data1.txt",'a')
        f.write(str(e))
        f.close()
    
    def view2(self):
        if(os.path.exists("data1.txt")):  #file exists or not
            with open("data1.txt", 'r') as fp:  #File open & close
                for e in fp:  #line by line read data
                    print(e)
        else:
            print("File does not exist")


    def search(self):
        fp= open("data.txt", "r") 
            # e: ek employee ka data 101,Anu, 10000
            # 102
        for e in fp:
                try:
                    e.index(str(id),0,2)
                    print(e)
                    break
                except ValueError:
                    pass
        else:
                print("Train not found")
                fp.close()
            
    def delete(self, id):
        # read file & check if id present
        found=False
        with open("data.txt",'r') as fp:
            details = []
            for e in fp:
                # If id match do nothing
                try:
                    e.index(str(id),0,2)                    
                except ValueError:
                    details.append(e)
                else:
                    found= True
                    # record present
                
        # write data back to file
        if(found == True):
            with open("data.txt","w") as fp:
                for x in details:
                    fp.write(x)
        else:
            print("Record not found")

            #For Admin login

    def addT(self,e):
         fp= open("data.txt",'a')
         fp.write(str(e))
         print("Details added succesfully")
         fp.close()

    def searchT(self, id):
        with open("data.txt", "r") as fp:
            # e: ek employee ka data 101,Anu, 10000
            # 102
            for e in fp:
                try:
                    e.index(str(id),0,3)
                    print(e)
                    break
                except ValueError:
                    pass
            else:
                print("Train not found")

    def deleteT(self, id):
        # read file & check if id present
        found=False
        with open("data.txt",'r') as fp:
            details = []
            for e in fp:
               
                # If id match do nothing
                try:
                    e.index(str(id),0,3)                    
                except ValueError:
                    details.append(e)
                else:
                    found= True
            
                    # record present

        # write data back to file
        if(found == True):
            with open("data.txt","w") as fp:
                for x in details:
                    fp.write(x)
                
        else:
            print("Record not found")

    def UpdateT(self,e):

         fp= open("data.txt", "a") 
            # e: ek employee ka data 101,Anu, 10000
            # 102
       
         fp.write(str(e))
         print("Details Updated succesfully")
         fp.close()
        

        




   
        
        

                    


                
