from Train import train
from Train_mngmt import trainMgmt

import datetime

if(__name__ =="__main__"):
    # e = Emp(101,"Adesh",10000)
    # print(e)
    m = trainMgmt()
   
    ch1=0
    while(ch1 !=3):
        print('''
              1.Admin Login
              2.User Login
              ''')
        ch1=int (input("Enter Your choice:"))
        if(ch1==1):
            Username = input("Enter Username:")
            Password = input("Enter Password:")
            if(Username == "Bhakti" and Password == "Khaire123"):
              print("Login Successfully")
              ch2=0
              while(ch2 !=10):
                print('''
                       1.Add Train Details
                       2.Search Train Details
                       3.Delete Train Details
                       4.Update Train Details
                       5.Display All details
                       6.Exit
                      ''')
                ch2=int(input("Enter Your Choice:"))
                if(ch2==1):
                    id = int(input("Enter Train id:"))
                    name =input("Enter name of train:")
                    seats =int(input("Enter the no. of seats available:"))
                    source =input("Enter Source:")
                    destination=input("Enter destination:")
                    pay=input("Enter Ticket Price as per head:")
                    e=train(id,name,seats,source,destination,pay)
                    m.addT(e)
                elif(ch2==2):
                     id = int(input("Enter Train id to search: "))
                     m.searchT(id)
                elif(ch2==3):
                    id = int(input("Enter the id of train to delete:"))
                    m.deleteT(id)
                    print("train details deleted successfully")
                elif(ch2==4):
                    m.display()
                    id_I= int(input("Enter the id of train to update:"))
                    m.deleteT(id) 
                    ID=int(input("Enter new details:"))
                    id = int(input("Enter Train id:"))
                    name =input("Enter name of train:")
                    seats =int(input("Enter the no. of seats available:"))
                    source =input("Enter Source:")
                    destination=input("Enter destination:")
                    pay=input("Enter Ticket Price as per head:")
                    e=train(id,name,seats,source,destination,pay)
                    m.addT(e)

                elif(ch2==5):
                    m.display()

                   
                elif(ch2==6):
                    print("Process exited")
                    break
            else:
              print('''
                    Login Failed...
                    Please Enter Correct Credentials
                    ''')
              
            break

                #For User login
        elif(ch1==2):
             c=0
             while(c!=3):
                 print('''
                        
                        1.Already Have an account? Login
                        2.Don't Have an account? Sign In
                          ''')
                 c1=int(input("Enter choice:"))
                 if(c1==1):
                    
                     Username = input("Enter Username:")
                     d=Username
        
                     Password = input("Enter Password:")
                     e=Password
                     if(Username ==d and Password ==e):
                       print("Login Successfully")
                       
                       ch1=0
                       while(ch1 !=7):
                            print('''  
                                       1.Display all available trains
                                       2. Search train to book 
                                       3. Book a Ticket
                                       4. View booking
                                       5. Cancel Booking
                                       6. Exit ''')
                            ch = int(input("Enter choice:"))
                            if(ch ==1 ):
                              m.display() 
                            elif(ch ==2):
                              id=int(input("Enter Train id:"))
                              m.search()
         
                            elif(ch ==3):
                               id = int(input("Enter id of train to book:"))
                               name = input("Enter name of train: ")
                               seats = int(input("Enter no. of seats to book:"))
                               source = input("Enter source:")
                               destination = input("Enter destination:")
                               print("You have to pay Rs.1000 per head  ")
                               print('''
                                         1.Pay with UPI
                                         2.Netbanking
                        
                                     ''')
                               ch3 = int(input("Enter Your choice to pay:"))
                               if(ch3 ==1):
                                 upi=int(input("Enter Your UPI ID:"))
                                 pay=int(input("Enter amount:"))
                                 print("Payment successfull Seats are booked")  
                               elif(ch3 ==2):
                                 upi=int(input("Enter Your Bnking Details:"))
                                 pay=int(input("Enter amount:"))
                                 print("Payment successfull Seats are booked") 
                                 e = train(id,name,seats,source,destination,pay)
                                 m.view(e)
                                 print("Ticket Booked Successfully")   

                            elif(ch ==4):
                              print("Booking Details are:")
                              m.view2()

                            elif(ch ==5):
                             id = int(input("Enter id to cancel Ticket: "))
                             num=int(input("Enter number of Booked seats to cancel: "))
                             refund=int(input("Enter UPI ID to refund:")) 
                             amount=int (input("Enter the paid amount for number of seats to be cancel:")) 
                             a=70/100*amount  
                             print("You will get ",a)
                             print("Note: Refundable amount will be 70 percent of the paid amount") 
                             print("Ticket Canceled Succesfully")       
                             break
                            elif(ch ==6):
                               break

                     else:
                       print("Login Failed...")
                       break
                 elif(c1==2):
                      
                      
                     
                      Username = input("Enter Username:")
                      a= Username
                      Password = input("Enter Password:")
                      b=Password
                      Confirm_password=input("Re-Enter Password: ")
                      Mobile=int(input("Enter mobile number:"))
                      c= Mobile
                      if(Username ==a and Password ==b and Confirm_password==b and Mobile==c):
                       print("Sign-In Successfully!!")
                       ch1=0
                       while(ch1 !=7):
                            print('''  
                                       1.Display all available trains
                                       2. Search train to book 
                                       3. Book a Ticket
                                       4. View booking
                                       5. Cancel Booking
                                       6. Exit ''')
                            ch = int(input("Enter choice:"))
                            if(ch ==1 ):
                              m.display() 
                            elif(ch ==2):
                              id=int(input("Enter Train id:"))
                              m.search()
         
                            elif(ch ==3):
                               id = int(input("Enter id of train to book:"))
                               name = input("Enter name of train: ")
                               seats = int(input("Enter no. of seats to book:"))
                               source = input("Enter source:")
                               destination = input("Enter destination:")
                               print("You have to pay Rs.1000 per head  ")
                               print('''
                                         1.Pay with UPI
                                         2.Netbanking
                        
                                     ''')
                               ch3 = int(input("Enter Your choice to pay:"))
                               if(ch3 ==1):
                                 upi=int(input("Enter Your UPI ID:"))
                                 pay=int(input("Enter amount:"))
                                 print("Payment successfull Seats are booked")  
                               elif(ch3 ==2):
                                 upi=int(input("Enter Your Bnking Details:"))
                                 pay=int(input("Enter amount:"))
                                 print("Payment successfull Seats are booked") 
                                 e = train(id,name,seats,source,destination,pay)
                                 m.view(e)
                                 print("Ticket Booked Successfully")   

                            elif(ch ==4):
                              print("Booking Details are:")
                              m.view2()

                            elif(ch ==5):
                             id = int(input("Enter id to cancel Ticket: "))
                             num=int(input("Enter number of Booked seats to cancel: "))
                             refund=int(input("Enter UPI ID to refund:")) 
                             amount=int (input("Enter the paid amount for number of seats to be cancel:")) 
                             a=70/100*amount  
                             print("You will get ",a)
                             print("Note: Refundable amount will be 70 percent of the paid amount") 
                             print("Ticket Canceled Succesfully")       
                             break
                            elif(ch ==6):
                               break
                      else:
                       print("Something Missing..")
                     
            